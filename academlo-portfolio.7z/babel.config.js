import React from '@vitejs/plugin-react-swc';
