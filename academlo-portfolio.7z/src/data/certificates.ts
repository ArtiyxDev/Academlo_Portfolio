export const certificates = [
   {
      name: 'Oracle Next Education',
      poster: 'one.png',
      link: 'https://app.aluracursos.com/program/certificate/529cddd8-8757-42a3-a6bd-ee6303fa5f9d',
   },
];
